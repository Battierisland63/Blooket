# blooket-hack

Hell i'm not gliz who created the blooket hacks. I got the repo from gliz. 

**this repo will not be updated at all. If you have any questions join the discord server below I'll be answering them.**
